-- MySQL dump 10.13  Distrib 5.1.67, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: thevoidc_titan
-- ------------------------------------------------------
-- Server version	5.1.67-rel14.3-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `messageId` int(11) NOT NULL,
  `fileId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fileId` (`fileId`),
  KEY `messageId` (`messageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendees`
--

DROP TABLE IF EXISTS `attendees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendees` (
  `attendeesId` int(11) NOT NULL AUTO_INCREMENT,
  `event` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `readStatus` int(11) NOT NULL,
  PRIMARY KEY (`attendeesId`),
  UNIQUE KEY `id` (`attendeesId`),
  KEY `event` (`event`),
  KEY `employee` (`employee`),
  KEY `readStatus` (`readStatus`),
  CONSTRAINT `attendees_ibfk_1` FOREIGN KEY (`event`) REFERENCES `event` (`id`) ON UPDATE NO ACTION,
  CONSTRAINT `attendees_ibfk_2` FOREIGN KEY (`employee`) REFERENCES `employees` (`id`) ON UPDATE NO ACTION,
  CONSTRAINT `attendees_ibfk_3` FOREIGN KEY (`readStatus`) REFERENCES `readStatus` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendees`
--

LOCK TABLES `attendees` WRITE;
/*!40000 ALTER TABLE `attendees` DISABLE KEYS */;
INSERT INTO `attendees` (`attendeesId`, `event`, `employee`, `readStatus`) VALUES (1,1,1,1),(2,1,3,1),(3,3,1,41),(4,3,2,42);
/*!40000 ALTER TABLE `attendees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employeeId` int(11) NOT NULL,
  `projectId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`employeeId`,`projectId`),
  KEY `employeeId` (`employeeId`),
  KEY `projectId` (`projectId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deptName` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` (`id`, `deptName`) VALUES (1,'Managers'),(2,'Office'),(3,'Automotive'),(4,'Sports'),(5,'Garden Center'),(6,'Hardware'),(7,'Housewares'),(8,'Cash'),(9,'Seasonal'),(10,'Store Standards'),(11,'Dealer');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employeeDept`
--

DROP TABLE IF EXISTS `employeeDept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employeeDept` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dept` (`dept`),
  KEY `employee` (`employee`),
  CONSTRAINT `employeeDept_ibfk_4` FOREIGN KEY (`employee`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `employeeDept_ibfk_3` FOREIGN KEY (`dept`) REFERENCES `department` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employeeDept`
--

LOCK TABLES `employeeDept` WRITE;
/*!40000 ALTER TABLE `employeeDept` DISABLE KEYS */;
INSERT INTO `employeeDept` (`id`, `dept`, `employee`) VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,5,6);
/*!40000 ALTER TABLE `employeeDept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employeeTask`
--

DROP TABLE IF EXISTS `employeeTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employeeTask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee` int(11) NOT NULL,
  `task` int(11) NOT NULL,
  `readStatus` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employee` (`employee`),
  KEY `readStatus` (`readStatus`),
  KEY `task` (`task`),
  CONSTRAINT `employeeTask_ibfk_5` FOREIGN KEY (`task`) REFERENCES `task` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employeeTask_ibfk_1` FOREIGN KEY (`employee`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `employeeTask_ibfk_3` FOREIGN KEY (`readStatus`) REFERENCES `readStatus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employeeTask`
--

LOCK TABLES `employeeTask` WRITE;
/*!40000 ALTER TABLE `employeeTask` DISABLE KEYS */;
INSERT INTO `employeeTask` (`id`, `employee`, `task`, `readStatus`) VALUES (4,3,1,1),(5,2,1,1),(6,1,2,43),(7,3,2,44);
/*!40000 ALTER TABLE `employeeTask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(40) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `thumb` varchar(255) NOT NULL DEFAULT '/img/thumb.jpg',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` (`id`, `username`, `firstName`, `lastName`, `email`, `phone`, `thumb`) VALUES (1,'ag553','Andrew','Gorzny','andrew.gorzny@cantire.com','4162555531','img/thumb.jpg'),(2,'vb678','Vishal','Bollu','vishal.bollu@cantire.com','4162555531','img/thumb.jpg'),(3,'rw364','Ryan','Webber','ryan.webber@cantire.com','4162555531','img/thumb.jpg'),(4,'ma456','Mark','Adams','m.a@gmail.com','4162555531','/img/thumb.jpg'),(5,'jf987','Joan','Freitas','j.f@gmail.com','4162555531','/img/thumb.jpg'),(6,'AA123','John','Doe','johndoe@cti.ca','5190000000','/img/thumb.jpg');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `eventDesc` text NOT NULL,
  `dateOfEvent` varchar(10) NOT NULL,
  `location` varchar(255) NOT NULL,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `creator` (`creator`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`creator`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` (`id`, `title`, `eventDesc`, `dateOfEvent`, `location`, `creator`) VALUES (1,'Jumpstart Day','Rosie MacLennan will be visiting our office to sign autographs','2013-05-24','CT Innovations',2),(3,'Ryans BBQ','I\'m not actually having a BBQ, this is just a test','Today, 3:0','My house',3);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fileName` varchar(255) NOT NULL,
  `dateUploaded` varchar(10) NOT NULL,
  `uploader` int(11) NOT NULL,
  `filePath` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uploader` (`uploader`),
  CONSTRAINT `file_ibfk_1` FOREIGN KEY (`uploader`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` (`id`, `fileName`, `dateUploaded`, `uploader`, `filePath`) VALUES (1,'Test PDF File - How To','2013-05-16',1,'/files/test.pdf'),(46,'headerBar.jpg','1368809993',1,'uploads/'),(47,'Logo_white.png','1368810123',1,'uploads/Logo_white.png'),(48,'mell','1368812833',1,'/text/');
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fileAccess`
--

DROP TABLE IF EXISTS `fileAccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fileAccess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` int(11) NOT NULL,
  `security` int(11) NOT NULL,
  `readStatus` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file` (`file`),
  KEY `security` (`security`),
  KEY `readStatus` (`readStatus`),
  CONSTRAINT `fileAccess_ibfk_4` FOREIGN KEY (`readStatus`) REFERENCES `readStatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fileAccess_ibfk_1` FOREIGN KEY (`file`) REFERENCES `file` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fileAccess_ibfk_2` FOREIGN KEY (`security`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fileAccess`
--

LOCK TABLES `fileAccess` WRITE;
/*!40000 ALTER TABLE `fileAccess` DISABLE KEYS */;
INSERT INTO `fileAccess` (`id`, `file`, `security`, `readStatus`) VALUES (2,1,2,1),(3,1,1,1),(47,46,2,91),(48,46,3,92),(49,46,1,93),(50,47,2,94),(51,47,3,95),(52,47,1,96),(53,48,2,98),(54,48,3,99),(55,48,1,100);
/*!40000 ALTER TABLE `fileAccess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `dateSent` varchar(10) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sender` (`sender`),
  CONSTRAINT `message_ibfk_1` FOREIGN KEY (`sender`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` (`id`, `device`, `sender`, `dateSent`, `message`) VALUES (1,0,1,'2013-05-15','Hey, hows it going. FIRST!'),(3,0,3,'2013-05-15','HEYHEYHEY'),(4,0,1,'2013-05-14','TEST 3 - Vishal, you get this dude?'),(5,0,1,'2013-05-16','Testing. hey Ryan, its Thursday!!!'),(7,0,1,'03-14-14','hello'),(8,0,1,'03-14-14','hello'),(21,0,2,'May 16, 20','Testing createmessage function Andrew...'),(25,0,1,'2013-05-AG','GETGE'),(26,0,1,'2013-05-AG','GETGE'),(27,0,1,'2013-05-AG','last one!'),(28,0,1,'2013-05-AG','TEST!'),(29,0,1,'2013-05-AG','Did you get this Vishal? How was lunch?\r\n'),(30,0,1,'2013-05-AG','HELLOOO??? you there'),(31,0,1,'2013-05-AG','sdfdfd'),(32,0,1,'2013-05-AG','HEY. DEMO SOON!');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projectName` varchar(25) NOT NULL,
  `projectDesc` text NOT NULL,
  `startDate` varchar(10) NOT NULL,
  `endDate` varchar(10) NOT NULL,
  `length` double NOT NULL,
  `assigner` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assigner` (`assigner`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`assigner`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` (`id`, `projectName`, `projectDesc`, `startDate`, `endDate`, `length`, `assigner`) VALUES (6,'Create TITAN','Make a web ap for CT that helps them communicate','Monday','June 1st',100,3);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectTask`
--

DROP TABLE IF EXISTS `projectTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectTask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project` int(11) NOT NULL,
  `employeeTask` int(11) NOT NULL,
  `readStatus` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project` (`project`),
  KEY `readStatus` (`readStatus`),
  KEY `employeeTask` (`employeeTask`),
  CONSTRAINT `projectTask_ibfk_4` FOREIGN KEY (`employeeTask`) REFERENCES `employeeTask` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `projectTask_ibfk_1` FOREIGN KEY (`project`) REFERENCES `project` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `projectTask_ibfk_3` FOREIGN KEY (`readStatus`) REFERENCES `readStatus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectTask`
--

LOCK TABLES `projectTask` WRITE;
/*!40000 ALTER TABLE `projectTask` DISABLE KEYS */;
INSERT INTO `projectTask` (`id`, `project`, `employeeTask`, `readStatus`) VALUES (5,6,4,73),(6,6,5,74),(7,6,6,75),(8,6,7,76);
/*!40000 ALTER TABLE `projectTask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `readStatus`
--

DROP TABLE IF EXISTS `readStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `readStatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `dateRead` varchar(10) NOT NULL,
  `readType` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `readStatus`
--

LOCK TABLES `readStatus` WRITE;
/*!40000 ALTER TABLE `readStatus` DISABLE KEYS */;
INSERT INTO `readStatus` (`id`, `status`, `dateRead`, `readType`) VALUES (1,0,'2013-05-15',1),(2,0,'2013-05-15',1),(3,1,'2013-05-15',1),(4,0,'2013-05-14',1),(5,1,'2013-05-16',1),(37,0,'Test Read ',-1),(38,0,'Test Read ',-1),(41,0,'Test Read ',-1),(42,0,'Test Read ',-1),(43,0,'Test Read ',-1),(44,0,'Test Read ',-1),(45,0,'Test Read ',-1),(46,0,'Test Read ',-1),(65,0,'Test Read ',-1),(66,0,'Test Read ',-1),(67,0,'Test Read ',-1),(68,0,'Test Read ',-1),(69,0,'Test Read ',-1),(70,0,'Test Read ',-1),(71,0,'Test Read ',-1),(72,0,'Test Read ',-1),(73,0,'Test Read ',-1),(74,0,'Test Read ',-1),(75,0,'Test Read ',-1),(76,0,'Test Read ',-1),(77,0,'1368801894',1),(78,0,'1368801894',1),(79,0,'1368803137',1),(80,0,'1368803137',1),(81,0,'1368803729',1),(82,0,'1368803729',1),(83,0,'1368803729',1),(84,0,'Test Read ',-1),(85,0,'Test Read ',-1),(86,0,'Test Read ',-1),(87,0,'Test Read ',-1),(88,0,'Test Read ',-1),(89,0,'Test Read ',-1),(90,0,'Test Read ',-1),(91,0,'1368809993',1),(92,0,'1368809993',1),(93,1,'1368817667',1),(94,0,'1368810123',1),(95,0,'1368810123',1),(96,0,'1368810123',1),(97,0,'Test Read ',-1),(98,0,'1368812833',1),(99,0,'1368812833',1),(100,0,'1368812833',1);
/*!40000 ALTER TABLE `readStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipients`
--

DROP TABLE IF EXISTS `recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `readStatus` int(1) NOT NULL,
  `restricted` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `message` (`message`),
  KEY `employee` (`employee`),
  KEY `readStatus` (`readStatus`),
  CONSTRAINT `recipients_ibfk_1` FOREIGN KEY (`message`) REFERENCES `message` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `recipients_ibfk_2` FOREIGN KEY (`employee`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `recipients_ibfk_5` FOREIGN KEY (`readStatus`) REFERENCES `readStatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipients`
--

LOCK TABLES `recipients` WRITE;
/*!40000 ALTER TABLE `recipients` DISABLE KEYS */;
INSERT INTO `recipients` (`id`, `message`, `employee`, `readStatus`, `restricted`) VALUES (4,1,2,1,0),(5,1,3,2,0),(6,3,1,3,0),(7,4,2,4,0),(8,5,3,5,0),(35,21,1,37,0),(36,21,3,38,0),(39,25,3,84,0),(40,26,3,85,0),(41,27,3,86,0),(42,28,3,87,0),(43,29,2,88,0),(44,30,2,89,0),(45,31,3,90,0),(46,32,3,97,0);
/*!40000 ALTER TABLE `recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskName` varchar(40) NOT NULL,
  `taskDesc` text NOT NULL,
  `startDate` varchar(10) NOT NULL,
  `endDate` varchar(10) NOT NULL,
  `completeDate` varchar(10) NOT NULL,
  `assignor` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assignor` (`assignor`),
  CONSTRAINT `task_ibfk_1` FOREIGN KEY (`assignor`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task`
--

LOCK TABLES `task` WRITE;
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
INSERT INTO `task` (`id`, `taskName`, `taskDesc`, `startDate`, `endDate`, `completeDate`, `assignor`, `status`) VALUES (1,'Code Inbox Functions','Using PHP, code functions...','2013-04-05','2013-05-31','',1,0),(2,'Sweep Isle 9 3/4','Grab the broom, and sweep the isle','Now','11:00','Incomplete',2,0);
/*!40000 ALTER TABLE `task` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-05-17 15:47:25
